;~function() {
    var sIpt = document.querySelector('.s_ipt'),
        sBtn = document.querySelector('.s_btn'),
        tips = document.createElement('div'),
        counter= 6,
        timer = null;

    tips.style.cssText = 'position: fixed;left: 0;top: 300px;z-index: 100000;width: 100%;font-size: 20px;text-align: center;';

    document.body.appendChild(tips);

    timer = setInterval(function() {
        counter -= 1;
        tips.innerHTML = counter + 's后对‘ chrome插件 ’进行搜索';
        if(counter == 0){
            tips.style.display = 'none';
            sIpt.value = 'chrome插件';
            clearInterval(timer);
        }
    }, 1000);
}()