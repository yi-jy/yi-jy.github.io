;~function() {
    var counter= 0,
        status = 'no',
        timer = null;

    chrome.browserAction.setBadgeBackgroundColor({color: '#0000ff'});
    chrome.browserAction.setBadgeText({text: status});

    timer = setInterval(function() {
        counter += 1;

        status = !(counter%5) ? 'yes' : 'no';

        chrome.browserAction.setBadgeText({text: status});
    }, 1000);
}()