;~function() {

    document.oncontextmenu = function(e){
        var target = e.target,
        	opt = {};

        opt.src = target.getAttribute('src');

        if(opt.src.indexOf('jpg') !== -1){
        	opt.format = 'jpg';
        }else if(opt.src.indexOf('jpeg') !== -1){
        	opt.format = 'jpeg';
        }else if(opt.src.indexOf('png') !== -1){
        	opt.format = 'png';
        }else if(opt.src.indexOf('gif') !== -1){
        	opt.format = 'gif';
        }else{
        	opt.format = '未知格式';
        }

        chrome.runtime.sendMessage(opt);

        console.log(opt);
    }

}()