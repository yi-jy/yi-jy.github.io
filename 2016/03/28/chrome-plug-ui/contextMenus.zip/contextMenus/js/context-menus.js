;~function() {

    chrome.contextMenus.create({
        type: 'normal',
        title: '地址：',
        contexts: ['image'],
        id: 'src'
    });

    chrome.contextMenus.create({
        type: 'normal',
        title: '格式：',
        contexts: ['image'],
        id: 'format'
    });

    chrome.runtime.onMessage.addListener(function(message, sender, sendResponse){
        chrome.contextMenus.update('src', {
            title: '地址：' + message.src,
            onclick: function(){
                window.open(message.src, '_blank');
            }
        });
        chrome.contextMenus.update('format', {
            title: '格式：' + message.format
        });
    });

}()